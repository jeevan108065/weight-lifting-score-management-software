
# Python program to create a table
import time   
from tkinter import *
from PIL import ImageTk, Image
import pyautogui
width, height= pyautogui.size()
  
class Table:
      
    def __init__(self,root,c,d):
        #logo placing
        self.img =Image.open('logopng.png')
        self.bg = ImageTk.PhotoImage(self.img)
        self.bg_image= Label(root, image=self.bg,bg='black')
        self.bg_image.grid(row=0,column=0)
        self.img2 =Image.open('AIU_logo.png')
        self.bg2 = ImageTk.PhotoImage(self.img2)
        self.bg_image2= Label(root, image=self.bg2,bg='black')
        self.bg_image2.place(x=width-1.2*width/15,y=0)
        self.competition_name_label=Label(root,
                                          text="All India Inter-Univesity \n Weightlifting Women Championship 2021-22",
                                          anchor="c",fg="red",bg='black',font=("Comic Sans MS",40,"bold"))
        self.competition_name_label.place(x=width-13.5*width/15,y=0)
        #logo ends
        for i in range(4):
            self.e = Entry(root, width=0,bd=0,bg='black')
            self.e.grid(row=i, column=1)
        # code for creating table
        self.e = Label(root, text=lst[len(lst)-1][4],fg='white',bg='black',font=('Arial',10,'bold'))
        self.e.grid(row=6, column=5)
        self.e = Label(root,text=lst[len(lst)-1][8],fg='white',bg='black',font=('Arial',10,'bold'))
        self.e.grid(row=6, column=8)
        for i in range(total_rows):
            for j in range(total_columns):
                val=""
                if lst[i][j] is not None:val=lst[i][j]
                if j==8 or j==12:
                    if i==0:
                        self.e = Label(root,text=val,width=10,border=5,anchor='w',
                                       bd=2,fg='white',bg='black',font=('Arial',12,'bold'))
                    elif i==1:
                        self.e = Label(root,text=val,width=10,border=5,anchor='w',
                                       bd=2, fg='black',bg='#90EE90',font=('Arial',12,'bold'))
                    elif i==2:
                        self.e = Label(root,text=val,width=10,border=5,anchor='w',
                                       bd=2, fg=d,bg=c,font=('Arial',10,'bold'))
                    elif i==3:
                        self.e = Label(root,text=val,width=10,border=5,anchor='w',
                                       bd=2, fg='black',bg='#FFFF99',font=('Arial',12,'bold'))
                    else:
                        self.e = Label(root,text=val,width=10,border=5,anchor='w',
                                       bd=2, fg='blue',font=('Arial',12,'bold'))
                else:
                    if i==0:
                        self.e = Label(root,text=val,width=8,border=5,anchor='w',
                                       bd=2,fg='white',bg='black',font=('Arial',12,'bold'))
                    elif i==1:
                        self.e = Label(root,text=val,width=8,border=5,anchor='w',
                                       bd=2, fg='black',bg='#90EE90',font=('Arial',12,'bold'))
                    elif i==2:
                        self.e = Label(root,text=val,width=8,border=5,anchor='w',
                                       bd=2, fg=d,bg=c,font=('Arial',12,'bold'))
                    elif i==3:
                        self.e = Label(root,text=val,width=8,border=5,anchor='w',
                                       bd=2, fg='black',bg='#FFFF99',font=('Arial',12,'bold'))
                    else:
                        self.e = Label(root,text=val,width=8,border=5,anchor='w',
                                       bd=2, fg='blue',font=('Arial',12,'bold'))
                if j==1:self.e['width']=22
                if j==2:self.e['width']=35
                self.e.grid(row=i+7, column=j)
                if lst[i][12]==0:
                    self.e['bg']='red'
                if (j>3 and j<7) or (j>7 and j<11):
                    if lst[i][j]=="f":
                        self.e['bg']='red'
                    elif str(lst[i][j]).isnumeric():
                        self.e['bg']='#00FF00'
        
        
# take the date

from openpyxl import load_workbook
from openpyxl import *
workbook = Workbook()
try:
    workbook = load_workbook(filename="sports_test_sorted.xlsx")
except:
    print("no file")
global sheet
sheet = workbook.active
lst = []
c=[]
r=4
for i in range(4,100):
    if sheet.cell(row=i,column=1).value is None :
        break
    else :
        r=r+1
for j in range(1,r+1):
    c=[]
    for i in range(1,14):
        c.append(sheet.cell(row=j, column=i).value)
    lst.append(c)

# find total number of rows and
# columns in list
total_rows = len(lst)-1
total_columns = len(lst[0])

  
# create root window
c=0
r=0
root = Tk()
root.config(bg='black')
root.state('zoomed')
t = Table(root,"orange",'black')
def refresh():
    root.destroy()
    import os
    os.system('python score_board.py')
def change(c):
    global r
    if c&1:
        t = Table(root,'white','black')
        root.update()
    else:t = Table(root,'black','white')
    root.update()
    time.sleep(1)
    r+=1
    if r==10:
        refresh()
    change(c^1)
change(c)
root.mainloop()
